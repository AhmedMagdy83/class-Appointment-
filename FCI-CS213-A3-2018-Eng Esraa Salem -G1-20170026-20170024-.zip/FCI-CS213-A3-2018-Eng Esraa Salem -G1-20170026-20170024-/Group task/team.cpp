#include <iostream>
#include<string>
using namespace std;
class  Time
{
public:
Time(){}
Time(string data[4]){
        for (int j=0;j<4;j++)
        arr[j]=data[j];
    }

void  operator  > (Time &obj){

if ((arr[3]=="am")&&(obj.arr[3]=="pm")){
        cout<<"\ntime1>time : ";
        cout<<"time one is greater than time two\n";}
else if (arr[3]==obj.arr[3]){
if (hour>obj.hour){
        cout<<"\ntime1>time : ";
        cout<<"time one is greater than time two\n";}
else if (hour==obj.hour){
    if (minute>obj.minute){
            cout<<"\ntime1>time : ";
            cout<<"time one is greater than time two\n";}
}
}

}
void  operator  <(Time &obj){
if ((arr[3]=="pm")&&(obj.arr[3]=="am")){
        cout<<"\ntime1<time : ";
        cout<<"time one is smaller than time two\n";}
else if (arr[3]==obj.arr[3]){
if (hour<obj.hour){
        cout<<"\ntime1<time : ";
        cout<<"time one is smaller than time two\n";}
else if (hour==obj.hour){
    if (minute<obj.minute){
            cout<<"\ntime1<time : ";
            cout<<"time one is smaller than time two\n";}
}
}


}
void operator ==(Time &obj){
if ((hour==obj.hour)&&(minute==obj.minute)&& (arr[3]==obj.arr[3])){
    cout<<"\ntime1==time : ";
    cout<<"they are equal\n";
}

}
void operator !=(Time &obj){
if ((hour!=obj.hour)||(minute==obj.minute)|| (arr[3]!=obj.arr[3])){
    cout<<"\ntime1!=time : ";
    cout<<"they are not equal\n";
}

}
friend istream& operator>>(istream& in ,Time &data);
friend ostream& operator << (ostream& out,Time &data);
private:
    string* arr;
   int hour,minute;
};

 istream& operator>>(istream& in ,Time &obj){
obj.arr=new string [4];
for (int j=0;j<4;j++)
        cin>>obj.arr[j];
        obj.hour=stoi(obj.arr[0]);
        obj.minute=stoi(obj.arr[2]);
        return in;
}

ostream& operator<< (ostream& out,Time &obj){
     for (int j=0;j<4;j++)
        out<<obj.arr[j];
        return out;
}


class appointment{
public:
    appointment(){}
void setinterval(){
    if (arr1[3]==arr2[3]){
        hour3=hour1-hour2;
        minute3=minute1-minute2;
        if (hour3<0)hour3*=-1;
        if (minute3<0)minute3*=-1;

    }
    else if ((arr1[3]=="pm")&&(arr2[3]=="am")){
        hour1+=12;
        hour3=hour1-hour2;
        minute3=minute1-minute2;
        if (hour3<0)hour3*=-1;
        if (minute3<0)minute3*=-1;

    }
     else if ((arr2[3]=="pm")&&(arr1[3]=="am")){
        hour2+=12;
        hour3=hour2-hour1;
        minute3=minute1-minute2;
        if (hour3<0)hour3*=-1;
        if (minute3<0)minute3*=-1;

    }
    }
void show(appointment &obj){
cout<<"\nthe interval of appointment1 is "<<hour3<<" hour(s) "<<" : "<<minute3<<" minute(s) "<<"\nthe interval of appointment2 is "<<obj.hour3<<" hour(s) "<<" : "<<obj.minute3<<" minute(s) "<<endl;
}
void  operator  > (appointment &obj){

if (hour3>obj.hour3){
                        cout<<"appointment1>appointment2: ";
        cout<<"appointment one is greater than appointment two\n";}
        else if (hour3==obj.hour3){
            if (minute3>obj.minute3){
                        cout<<"appointment1>appointment2: ";
        cout<<"appointment one is greater than appointment two\n";}
        }

}
void  operator  <(appointment &obj){
if (hour3<obj.hour3){
        cout<<"appointment1<appointment2: ";
        cout<<"appointment one is smaller than appointment two\n";}

else if (hour3==obj.hour3){
            if (minute3<obj.minute3){
                        cout<<"appointment1<appointment2: ";
        cout<<"appointment one is smaller than appointment two\n";}
        }


}
void operator ==(appointment &obj){
if ((hour3==obj.hour3)&&(minute3==obj.minute3)){
                cout<<"appointment1==appointment2: ";
        cout<<"appointment one is equal to than appointment two\n";}

}


void operator !=(appointment &obj){
if ((hour3!=obj.hour3)||(minute3!=obj.minute3)){
        cout<<"appointment1!=appointment2: ";
        cout<<"appointment one is not equal to than appointment two\n";}

}

   friend istream& operator>>(istream& in ,appointment &obj);
   friend ostream& operator<< (ostream& out,appointment &obj);

private:
    string* arr1;
    string* arr2;
    int hour1,hour2,minute1,minute2,hour3,minute3;

};
istream& operator>>(istream& in ,appointment &obj){
obj.arr1=new string [4];
obj.arr2=new string [4];
cout<<"enter start of your appointment \n";
for (int j=0;j<4;j++)
        cin>>obj.arr1[j];
cout<<"enter end of your appointment \n";
for (int j=0;j<4;j++)
        in>>obj.arr2[j];
        obj.hour1=stoi(obj.arr1[0]);
        obj.minute1=stoi(obj.arr1[2]);
        obj.hour2=stoi(obj.arr2[0]);
        obj.minute2=stoi(obj.arr2[2]);
        return in;
}

ostream& operator<< (ostream& out,appointment &obj){
    cout<<"will start from ";
     for (int j=0;j<4;j++)
        out<<obj.arr1[j];
        out<<" to ";
     for (int j=0;j<4;j++)
        out<<obj.arr2[j];
        return out;
}

int main()
{

Time time1,time2;
appointment Appointment1,Appointment2 ;
while(true){
cout<<"please enter your fist time\n";
cin>>time1;
cout<<"please enter your second time\n";
cin>>time2;
cout<<"\ntime one is \n";
cout<<time1;
cout<<"\ntime two is \n";
cout<<time2;
time1>time2;
time1<time2;
time1==time2;
time1!=time2;

cout<<"Appointment1\n";
cin>>Appointment1;
cout<<"\nAppointment2\n";
cin>>Appointment2;
Appointment1.setinterval();
Appointment2.setinterval();

Appointment1>Appointment2;
Appointment1<Appointment2;
Appointment1==Appointment2;
Appointment1!=Appointment2;
int details=0;
cout<<"\n if you want to show the details press 1 or to 0 to enter another appointment\n";
cin>>details;
if (details==1)
{
 cout<<"appointment1 "<<Appointment1<<"\nappointment2 "<<Appointment2;
 Appointment1.show(Appointment2);

}


}
    return 0;
}
