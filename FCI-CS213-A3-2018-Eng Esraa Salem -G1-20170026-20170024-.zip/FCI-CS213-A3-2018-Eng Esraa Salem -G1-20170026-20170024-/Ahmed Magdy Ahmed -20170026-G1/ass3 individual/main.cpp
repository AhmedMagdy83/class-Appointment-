#include <iostream>
#include <vector>

using namespace std;

bool isMeasurable(int target, vector<int> & weights);

int main()
{
	vector<int> sampleWeights;
	sampleWeights.push_back(1);
	sampleWeights.push_back(3);
	sampleWeights.push_back(5);
	sampleWeights.push_back(7);
	cout<<"I have 1,3,5,7 weights "<<endl<<endl;
	int m ;
	cout<<"Enter your weights "<<endl;
	cin>>m;
	cout << isMeasurable(m, sampleWeights);
	return 0;
}

bool isMeasurable(int target, vector<int> & weights)
{
	int sum = 0;
	for (int i = 0; i < weights.size(); i++)
	{
		if (target == weights[i])
			return 1;
		sum += weights[i];
	}
	for (int i = 0; i < weights.size(); i++)
	{
		if (target == (sum - weights[i]))
			return 1;
	}
	if (target > sum || weights.size() == 0) // base case
		return 0;
	else if (target == sum)
		return 1;
	else
	{
		for (int i = 1; i < weights.size(); i++)
		{
			if (target == (weights[0] + weights[i]))
				return true;
		}
		vector<int> newWeights;
		for (int i = 1; i < weights.size(); i++)
		{
			newWeights.push_back(weights[i]);
		}
// remove first item from the weights and put it on the left side by adding it to target
// OR send the new weights again to check for the case of the (target == (weights[0] + weights[i]))
// which is going to check the 2nd item and the all other items and each item and the third item with the other items and so on..
		return isMeasurable(target + weights[0], newWeights) || isMeasurable(target, newWeights);
	}
}
