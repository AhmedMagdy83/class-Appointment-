#include <iostream>

using namespace std;
int Combination_With_Pascal_Triangle(const int row,const int col)
{
    if ((row == 0)||(row == 1)||(col== 0)||(col == row))
        return 1;
    else
    {
        return(Combination_With_Pascal_Triangle(row-1,col-1)+Combination_With_Pascal_Triangle(row-1,col));
    }
}
int main()
{
    int row, x, y, c, q,column;
    while(true){
  cout<<"Enter the number of rows: \n";
  cin>>row;

    cout<<"Enter the number of column: \n";

cin>>column;
    cout << Combination_With_Pascal_Triangle(row,column) << endl;
  for (y = 0; y < row; y++){
        c = 1;
        for(q = 0; q < row - y; q++){
cout<<" ";
        }
        for (x = 0; x <= y; x++){
cout<<c<<" ";
              c = c * (y - x) / (x + 1);
        }
cout<<endl;
  }
cout<<endl;
    }
    return 0;
}
